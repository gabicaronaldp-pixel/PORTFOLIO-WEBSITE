import React from 'react';
import { motion } from 'motion/react';
import { Beaker, ExternalLink, FileText, Share2 } from 'lucide-react';
import { cn } from '../lib/utils';

const Research = () => {
  const researchWork = [
    {
      id: '1',
      title: 'Optimizing Latent Space for Generative Models',
      description: 'Research focused on improving the interpretability and control of latent representations in Variational Autoencoders (VAEs).',
      image: 'https://picsum.photos/seed/research1/800/600',
      link: '#',
      status: 'Published - ICML Workshop',
      tags: ['Generative AI', 'Latent Space', 'Optimization']
    },
    {
      id: '2',
      title: 'Robustness in Adversarial Neural Networks',
      description: 'Investigating defense mechanisms against adversarial attacks in computer vision models using stochastic regularization.',
      image: 'https://picsum.photos/seed/research2/800/600',
      link: '#',
      status: 'Under Review',
      tags: ['Security', 'Deep Learning', 'Robustness']
    }
  ];

  return (
    <div className="pt-24 pb-20 bg-black min-h-screen">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-16">
          <h1 className="text-4xl md:text-6xl font-black text-white mb-4">Research Work</h1>
          <div className="w-20 h-1.5 bg-blue-600 rounded-full"></div>
        </div>

        <div className="space-y-16">
          {researchWork.map((work, idx) => (
            <motion.div
              key={work.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.2 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
            >
              <div className={cn(
                "relative rounded-2xl overflow-hidden border border-white/5 group",
                idx % 2 !== 0 ? "lg:order-2" : ""
              )}>
                <img src={work.image} alt={work.title} className="w-full aspect-video object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-6 left-6">
                  <span className="px-3 py-1 bg-blue-600 text-white text-[10px] font-black uppercase rounded">
                    {work.status}
                  </span>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex flex-wrap gap-2">
                  {work.tags.map(tag => (
                    <span key={tag} className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">#{tag}</span>
                  ))}
                </div>
                <h2 className="text-3xl font-bold text-white leading-tight">{work.title}</h2>
                <p className="text-gray-400 text-lg leading-relaxed">{work.description}</p>
                
                <div className="pt-6 flex flex-wrap gap-4">
                  <button className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all flex items-center gap-2">
                    <FileText className="w-5 h-5" /> Read Paper
                  </button>
                  <button className="px-6 py-3 bg-zinc-900 hover:bg-zinc-800 text-white font-bold rounded-xl border border-white/5 transition-all flex items-center gap-2">
                    <Share2 className="w-5 h-5" /> Share
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Research Interests */}
        <div className="mt-32 p-12 bg-zinc-950 rounded-3xl border border-blue-900/20 text-center">
          <Beaker className="w-12 h-12 text-blue-500 mx-auto mb-6" />
          <h3 className="text-2xl font-bold text-white mb-4">Research Interests</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {[
              'Explainable AI (XAI)',
              'Federated Learning',
              'Neural Architecture Search',
              'Self-Supervised Learning',
              'AI Ethics'
            ].map(interest => (
              <span key={interest} className="px-6 py-2 bg-zinc-900 text-gray-400 rounded-full text-sm font-medium border border-white/5">
                {interest}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Research;
