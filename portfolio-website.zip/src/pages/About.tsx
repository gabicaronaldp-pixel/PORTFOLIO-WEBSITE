import React from 'react';
import { motion } from 'motion/react';
import { User, Code, Terminal, Award, BookOpen } from 'lucide-react';

const About = () => {
  const technicalSkills = [
    'Python', 'PyTorch', 'TensorFlow', 'Scikit-Learn', 'OpenCV', 'SQL', 'Git', 'Docker', 'C++', 'Java'
  ];

  const nonTechnicalSkills = [
    'Problem Solving', 'Team Leadership', 'Public Speaking', 'Technical Writing', 'Project Management'
  ];

  return (
    <div className="pt-24 pb-20 bg-black min-h-screen">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3 mb-4"
          >
            <User className="w-6 h-6 text-blue-500" />
            <h1 className="text-4xl md:text-5xl font-black text-white">About Me</h1>
          </motion.div>
          <div className="w-24 h-1.5 bg-blue-600 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Bio */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            <p className="text-gray-300 text-lg leading-relaxed">
              I am a passionate AI/ML student currently in my 2nd year of B.Tech CSE with a specialization in Artificial Intelligence and Machine Learning at Lovely Professional University (LPU).
            </p>
            <p className="text-gray-400 leading-relaxed">
              My journey into the world of intelligence started with a fascination for how machines can learn from data. Since then, I've been dedicated to mastering the mathematical foundations and practical implementations of deep learning models.
            </p>
            <p className="text-gray-400 leading-relaxed">
              I believe in the power of AI to solve real-world problems, from healthcare diagnostics to autonomous systems. My goal is to contribute to research that pushes the boundaries of what's possible with neural architectures.
            </p>
            
            <div className="pt-8 grid grid-cols-2 gap-6">
              <div className="p-4 bg-zinc-900 rounded-xl border border-white/5">
                <Award className="w-6 h-6 text-blue-500 mb-2" />
                <h4 className="text-white font-bold">5+ Wins</h4>
                <p className="text-gray-500 text-xs uppercase font-bold">Hackathons</p>
              </div>
              <div className="p-4 bg-zinc-900 rounded-xl border border-white/5">
                <BookOpen className="w-6 h-6 text-blue-500 mb-2" />
                <h4 className="text-white font-bold">3 Papers</h4>
                <p className="text-gray-500 text-xs uppercase font-bold">Research</p>
              </div>
            </div>
          </motion.div>

          {/* Skills */}
          <div className="space-y-10">
            {/* Technical */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <div className="flex items-center gap-2 mb-6">
                <Terminal className="w-5 h-5 text-blue-500" />
                <h3 className="text-xl font-bold text-white uppercase tracking-wider">Technical Skills</h3>
              </div>
              <div className="flex flex-wrap gap-3">
                {technicalSkills.map((skill) => (
                  <span 
                    key={skill}
                    className="px-4 py-2 bg-blue-600/10 text-blue-400 border border-blue-600/20 rounded-lg text-sm font-medium hover:bg-blue-600 hover:text-white transition-all cursor-default"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>

            {/* Non-Technical */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <div className="flex items-center gap-2 mb-6">
                <Code className="w-5 h-5 text-blue-500" />
                <h3 className="text-xl font-bold text-white uppercase tracking-wider">Soft Skills</h3>
              </div>
              <div className="flex flex-wrap gap-3">
                {nonTechnicalSkills.map((skill) => (
                  <span 
                    key={skill}
                    className="px-4 py-2 bg-zinc-900 text-gray-400 border border-white/5 rounded-lg text-sm font-medium hover:border-blue-500/50 transition-all cursor-default"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
