import React from 'react';
import { motion } from 'motion/react';
import { GraduationCap, BookOpen, Star, Award } from 'lucide-react';

const Academics = () => {
  const education = [
    {
      level: 'B.Tech CSE (AI & ML)',
      institution: 'Lovely Professional University (LPU)',
      period: '2022 - 2026',
      status: 'Current (2nd Year)',
      details: 'Focusing on core AI concepts, neural networks, and advanced data structures. Maintaining a strong academic record with active participation in research seminars.',
      grade: 'CGPA: 9.0'
    },
    {
      level: '12th Grade (Senior Secondary)',
      institution: 'Science & Mathematics Stream',
      period: '2020 - 2022',
      status: 'Completed',
      details: 'Specialized in Physics, Chemistry, and Mathematics. Developed strong analytical and logical reasoning skills.',
      grade: 'Percentage: 95%'
    },
    {
      level: '10th Grade (Secondary)',
      institution: 'CBSE Board',
      period: '2018 - 2020',
      status: 'Completed',
      details: 'Excelled in science and mathematics, laying the foundation for a career in engineering.',
      grade: 'CGPA: 10.0'
    }
  ];

  return (
    <div className="pt-24 pb-20 bg-black min-h-screen">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-16">
          <h1 className="text-4xl md:text-6xl font-black text-white mb-4">Academic Journey</h1>
          <div className="w-20 h-1.5 bg-blue-600 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Timeline */}
          <div className="lg:col-span-2 space-y-12">
            {education.map((edu, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="relative pl-8 before:absolute before:left-0 before:top-0 before:bottom-0 before:w-px before:bg-blue-900/50"
              >
                <div className="absolute left-[-4px] top-0 w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]"></div>
                <div className="p-8 bg-zinc-900/50 border border-white/5 rounded-2xl hover:border-blue-500/30 transition-all">
                  <div className="flex flex-col sm:row sm:items-center justify-between gap-4 mb-4">
                    <div>
                      <span className="text-blue-500 text-[10px] font-bold uppercase tracking-widest mb-1 block">{edu.period}</span>
                      <h3 className="text-2xl font-bold text-white">{edu.level}</h3>
                    </div>
                    <span className="px-3 py-1 bg-blue-600/10 text-blue-500 text-xs font-bold rounded-full border border-blue-600/20">
                      {edu.grade}
                    </span>
                  </div>
                  <p className="text-gray-300 font-medium mb-4">{edu.institution}</p>
                  <p className="text-gray-500 text-sm leading-relaxed">{edu.details}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Sidebar Info */}
          <div className="space-y-8">
            <div className="p-8 bg-zinc-900 rounded-2xl border border-white/5">
              <div className="flex items-center gap-3 mb-6">
                <Star className="w-5 h-5 text-blue-500" />
                <h3 className="text-lg font-bold text-white uppercase tracking-widest">Key Focus Areas</h3>
              </div>
              <ul className="space-y-4">
                {[
                  'Neural Networks',
                  'Advanced Algorithms',
                  'Statistical Learning',
                  'Computer Architecture',
                  'Optimization Theory'
                ].map(item => (
                  <li key={item} className="flex items-center gap-3 text-gray-400 text-sm">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-600"></div>
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-8 bg-blue-600 rounded-2xl text-white">
              <GraduationCap className="w-10 h-10 mb-4" />
              <h3 className="text-xl font-bold mb-2">Continuous Learning</h3>
              <p className="text-blue-100 text-sm leading-relaxed">
                Actively pursuing online certifications from top universities to stay updated with the rapidly evolving AI landscape.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Academics;
