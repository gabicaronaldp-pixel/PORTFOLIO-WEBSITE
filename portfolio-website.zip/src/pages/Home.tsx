import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Code, Cpu, Database, Globe, Brain } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden bg-black">
        {/* Animated Background Grid */}
        <div className="absolute inset-0 z-0 opacity-20">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e40af_1px,transparent_1px),linear-gradient(to_bottom,#1e40af_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
        </div>

        <div className="container mx-auto px-4 z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-xs font-bold tracking-widest text-blue-500 uppercase bg-blue-500/10 rounded-full border border-blue-500/20">
              AI / ML Student & Researcher
            </span>
            <h1 className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tight">
              Building the <span className="text-blue-600">Future</span> <br />
              with Intelligence.
            </h1>
            <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
              Specializing in Deep Learning, Computer Vision, and NLP. 
              Currently exploring the intersection of AI and Robotics at LPU.
            </p>
            <div className="flex flex-col sm:row items-center justify-center gap-4">
              <Link
                to="/projects"
                className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all transform hover:scale-105 flex items-center gap-2 shadow-lg shadow-blue-600/20"
              >
                View My Work <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/contact"
                className="px-8 py-4 bg-white/5 hover:bg-white/10 text-white font-bold rounded-xl border border-white/10 transition-all"
              >
                Let's Talk
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Floating AI Elements */}
        <motion.div
          animate={{ y: [0, -20, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 left-10 hidden lg:block opacity-40"
        >
          <Cpu className="w-16 h-16 text-blue-500" />
        </motion.div>
        <motion.div
          animate={{ y: [0, 20, 0] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-1/4 right-10 hidden lg:block opacity-40"
        >
          <Database className="w-16 h-16 text-blue-500" />
        </motion.div>
      </section>

      {/* Quick Stats Section */}
      <section className="py-20 bg-zinc-950 border-y border-blue-900/20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: 'Projects Completed', value: '15+' },
              { label: 'Research Papers', value: '3' },
              { label: 'Hackathons Won', value: '5' },
              { label: 'Certifications', value: '10+' },
            ].map((stat, idx) => (
              <div key={idx} className="text-center">
                <h3 className="text-4xl font-black text-white mb-2">{stat.value}</h3>
                <p className="text-gray-500 text-sm uppercase tracking-wider font-bold">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Core Expertise */}
      <section className="py-24 bg-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-black text-white mb-4">Core Expertise</h2>
            <div className="w-20 h-1.5 bg-blue-600 mx-auto rounded-full"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <Brain className="w-8 h-8" />,
                title: 'Deep Learning',
                desc: 'Designing and training complex neural networks for various applications.'
              },
              {
                icon: <Globe className="w-8 h-8" />,
                title: 'Computer Vision',
                desc: 'Enabling machines to see and understand the visual world through AI.'
              },
              {
                icon: <Code className="w-8 h-8" />,
                title: 'NLP',
                desc: 'Processing and understanding human language using state-of-the-art models.'
              }
            ].map((skill, idx) => (
              <motion.div
                key={idx}
                whileHover={{ y: -10 }}
                className="p-8 bg-zinc-900/50 border border-white/5 rounded-2xl hover:border-blue-500/50 transition-all group"
              >
                <div className="p-3 bg-blue-600/10 rounded-xl w-fit mb-6 group-hover:bg-blue-600 transition-colors">
                  <div className="text-blue-500 group-hover:text-white">{skill.icon}</div>
                </div>
                <h3 className="text-xl font-bold text-white mb-4">{skill.title}</h3>
                <p className="text-gray-400 leading-relaxed">{skill.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
