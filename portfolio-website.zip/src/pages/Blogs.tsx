import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Tag, ArrowRight } from 'lucide-react';
import { BLOGS } from '../constants';

const Blogs = () => {
  return (
    <div className="pt-24 pb-20 bg-black min-h-screen">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-16">
          <h1 className="text-4xl md:text-6xl font-black text-white mb-4">Latest Insights</h1>
          <p className="text-gray-400 max-w-xl">Sharing my thoughts on AI, machine learning, and the future of technology.</p>
          <div className="w-20 h-1.5 bg-blue-600 mt-6 rounded-full"></div>
        </div>

        {/* Featured Blog */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative rounded-3xl overflow-hidden mb-16 group"
        >
          <div className="aspect-[21/9] w-full">
            <img src={BLOGS[0].image} alt={BLOGS[0].title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-8 md:p-12 max-w-3xl">
            <span className="px-3 py-1 bg-blue-600 text-white text-[10px] font-black uppercase rounded mb-4 inline-block">
              Featured Post
            </span>
            <h2 className="text-3xl md:text-5xl font-black text-white mb-4 leading-tight group-hover:text-blue-500 transition-colors">
              {BLOGS[0].title}
            </h2>
            <p className="text-gray-300 text-lg mb-6 line-clamp-2">{BLOGS[0].excerpt}</p>
            <div className="flex items-center gap-6 text-gray-400 text-sm font-medium">
              <span className="flex items-center gap-2"><Calendar className="w-4 h-4" /> {BLOGS[0].date}</span>
              <span className="flex items-center gap-2"><Tag className="w-4 h-4" /> {BLOGS[0].category}</span>
            </div>
          </div>
        </motion.div>

        {/* Blog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {BLOGS.slice(1).concat(BLOGS).map((blog, idx) => (
            <motion.div
              key={`${blog.id}-${idx}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-zinc-900/50 border border-white/5 rounded-2xl overflow-hidden hover:border-blue-500/50 transition-all flex flex-col"
            >
              <div className="h-48 overflow-hidden">
                <img src={blog.image} alt={blog.title} className="w-full h-full object-cover transition-transform group-hover:scale-110" />
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-blue-500 text-[10px] font-black uppercase tracking-widest">{blog.category}</span>
                  <span className="text-gray-500 text-[10px] font-medium">{blog.date}</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-3 line-clamp-2">{blog.title}</h3>
                <p className="text-gray-400 text-sm mb-6 line-clamp-3">{blog.excerpt}</p>
                <button className="mt-auto flex items-center gap-2 text-sm font-bold text-blue-500 hover:text-blue-400 transition-colors">
                  Read More <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Blogs;
