import React from 'react';
import { motion } from 'motion/react';
import { Award, Trophy, ExternalLink, Calendar } from 'lucide-react';
import { CERTIFICATES, HACKATHONS } from '../constants';

const Achievements = () => {
  return (
    <div className="pt-24 pb-20 bg-black min-h-screen">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-16">
          <h1 className="text-4xl md:text-6xl font-black text-white mb-4">Achievements</h1>
          <div className="w-20 h-1.5 bg-blue-600 rounded-full"></div>
        </div>

        {/* Certificates Section */}
        <section className="mb-24">
          <div className="flex items-center gap-3 mb-10">
            <Award className="w-6 h-6 text-blue-500" />
            <h2 className="text-2xl font-bold text-white uppercase tracking-widest">Professional Certifications</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {CERTIFICATES.map((cert, idx) => (
              <motion.div
                key={cert.id}
                initial={{ opacity: 0, x: idx % 2 === 0 ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="group bg-zinc-900/50 border border-white/5 rounded-2xl overflow-hidden flex flex-col sm:flex-row hover:border-blue-500/30 transition-all"
              >
                <div className="sm:w-48 h-48 sm:h-auto overflow-hidden">
                  <img src={cert.image} alt={cert.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                </div>
                <div className="p-6 flex-1">
                  <span className="text-blue-500 text-[10px] font-bold uppercase tracking-widest mb-2 block">{cert.issuer}</span>
                  <h3 className="text-xl font-bold text-white mb-2">{cert.title}</h3>
                  <p className="text-gray-400 text-sm mb-4 leading-relaxed">{cert.description}</p>
                  <div className="flex items-center justify-between mt-auto">
                    <span className="text-gray-500 text-xs font-medium">{cert.date}</span>
                    <button className="text-blue-500 hover:text-blue-400 text-sm font-bold flex items-center gap-1">
                      Verify <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Hackathons Section */}
        <section>
          <div className="flex items-center gap-3 mb-10">
            <Trophy className="w-6 h-6 text-blue-500" />
            <h2 className="text-2xl font-bold text-white uppercase tracking-widest">Hackathons & Competitions</h2>
          </div>
          <div className="space-y-6">
            {HACKATHONS.map((hack, idx) => (
              <motion.div
                key={hack.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="p-8 bg-zinc-900/30 border border-white/5 rounded-2xl hover:bg-zinc-900/50 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-bold text-white">{hack.title}</h3>
                    {hack.position && (
                      <span className="px-2 py-0.5 bg-blue-600 text-white text-[10px] font-black uppercase rounded">
                        {hack.position}
                      </span>
                    )}
                  </div>
                  <p className="text-gray-400 text-sm leading-relaxed max-w-2xl">{hack.description}</p>
                </div>
                <div className="flex items-center gap-2 text-gray-500 text-sm font-medium whitespace-nowrap">
                  <Calendar className="w-4 h-4" /> {hack.date}
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Achievements;
