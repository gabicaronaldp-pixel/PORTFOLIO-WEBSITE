import { Project, Certificate, Hackathon, Feedback, BlogPost } from './types';

export const PROJECTS: Project[] = [
  {
    id: '1',
    title: 'Autonomous Drone Navigation',
    description: 'Deep reinforcement learning based navigation system for drones in complex indoor environments.',
    image: 'https://picsum.photos/seed/drone/800/600',
    link: 'https://github.com',
    previewAvailable: true,
    languages: ['Python', 'PyTorch', 'ROS'],
    tags: ['AI', 'Robotics', 'Computer Vision'],
    status: 'completed'
  },
  {
    id: '2',
    title: 'Medical Image Segmentation',
    description: 'U-Net based architecture for precise segmentation of brain tumors from MRI scans.',
    image: 'https://picsum.photos/seed/medical/800/600',
    link: 'https://github.com',
    previewAvailable: false,
    languages: ['Python', 'TensorFlow', 'OpenCV'],
    tags: ['Healthcare', 'Deep Learning'],
    status: 'completed'
  },
  {
    id: '3',
    title: 'Real-time Sentiment Bot',
    description: 'A Discord bot that analyzes sentiment of messages in real-time using BERT.',
    image: 'https://picsum.photos/seed/bot/800/600',
    link: 'https://github.com',
    previewAvailable: true,
    languages: ['JavaScript', 'Python', 'Transformers'],
    tags: ['NLP', 'Bot', 'API'],
    status: 'in-progress'
  }
];

export const CERTIFICATES: Certificate[] = [
  {
    id: '1',
    title: 'Deep Learning Specialization',
    issuer: 'Coursera (DeepLearning.AI)',
    description: 'Comprehensive 5-course specialization covering neural networks, CNNs, RNNs, and more.',
    image: 'https://picsum.photos/seed/cert1/800/600',
    date: 'Dec 2023'
  },
  {
    id: '2',
    title: 'Machine Learning Professional',
    issuer: 'Google Cloud',
    description: 'Professional certification for deploying ML models on GCP.',
    image: 'https://picsum.photos/seed/cert2/800/600',
    date: 'Oct 2023'
  }
];

export const HACKATHONS: Hackathon[] = [
  {
    id: '1',
    title: 'Smart India Hackathon 2023',
    description: 'Developed an AI-based solution for real-time traffic management.',
    date: 'Sept 2023',
    position: 'Finalist'
  },
  {
    id: '2',
    title: 'LPU Code-A-Thon',
    description: 'Built a predictive model for student performance analysis.',
    date: 'Mar 2023',
    position: 'Winner'
  }
];

export const FEEDBACKS: Feedback[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    image: 'https://i.pravatar.cc/150?u=sarah',
    role: 'Senior Data Scientist',
    rating: 5,
    skillTag: 'PyTorch',
    productivityBoost: '40%',
    comment: 'Exceptional understanding of complex neural architectures. Delivered the model ahead of schedule.'
  },
  {
    id: '2',
    name: 'Michael Chen',
    image: 'https://i.pravatar.cc/150?u=michael',
    role: 'Project Manager',
    rating: 4,
    skillTag: 'Python',
    productivityBoost: '25%',
    comment: 'Great problem-solving skills and very communicative throughout the project lifecycle.'
  }
];

export const BLOGS: BlogPost[] = [
  {
    id: '1',
    title: 'The Future of Generative AI',
    excerpt: 'Exploring how LLMs are reshaping the creative industry and software development.',
    date: 'Feb 20, 2024',
    category: 'AI Trends',
    image: 'https://picsum.photos/seed/blog1/800/600'
  },
  {
    id: '2',
    title: 'Getting Started with PyTorch',
    excerpt: 'A comprehensive guide for beginners to start their deep learning journey.',
    date: 'Jan 15, 2024',
    category: 'Tutorial',
    image: 'https://picsum.photos/seed/blog2/800/600'
  }
];
